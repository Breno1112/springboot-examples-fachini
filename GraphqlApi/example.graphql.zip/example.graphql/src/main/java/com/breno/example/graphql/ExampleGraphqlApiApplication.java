package com.breno.example.graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleGraphqlApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleGraphqlApiApplication.class, args);
	}

}
