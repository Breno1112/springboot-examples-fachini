package com.breno.example.graphql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleGraphqlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
